
//import the lodash module

//Create a function to find a maximum value from number array.
function findMaxValue(arr) {
  return arr.sort((a,b)=>b-a)[0]
  
}



//Create a function to return all values from numbers array 
//which are greater than the second parameter.​


//Create a function to return all values of employeeName array in capital letters.




module.exports = {
  findMaxValue,
  // filterValues,
  // nameInCapital,
  
}
